-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: myfueldb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car` (
  `FK_customerId` varchar(50) DEFAULT NULL,
  `carLicenseNumber` varchar(50) NOT NULL,
  `FK_fuelType` enum('Petrol','Diesel','ScooterFuel') DEFAULT NULL,
  `Manufacturer` varchar(50) DEFAULT NULL,
  `carModel` varchar(50) DEFAULT NULL,
  `manufacturerYear` year DEFAULT NULL,
  `carOwner` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`carLicenseNumber`),
  KEY `FK_fuelType` (`FK_fuelType`),
  KEY `FK_customerId` (`FK_customerId`),
  CONSTRAINT `car_ibfk_2` FOREIGN KEY (`FK_fuelType`) REFERENCES `fuel` (`fuelType`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `car_ibfk_3` FOREIGN KEY (`FK_customerId`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car`
--

LOCK TABLES `car` WRITE;
/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES ('718436985','12456397','Petrol','VW','Golf',2008,'Brett Mccabe'),('718436985','1789596','Diesel','VW','Passat',2013,'Brett Mccabe'),('132584962','4156471','Diesel','Land Rover','Range Rover',2016,'Manuel Mosley'),('485963247','4568712','Petrol','Seat','Mii',2018,'Hugo Frazier'),('132584962','5245637','Diesel','Land Rover','Defender',2015,'Manuel Mosley'),('485963247','5412396','Petrol','Seat','Ibiza',2018,'Hugo Frazier'),('856326971','5478936','Diesel','BMW','X6',2017,'Sally Swan'),('856326971','5695174','Diesel','BMW','X5',2017,'Sally Swan'),('523718504','6536974','Petrol','Audi','A1',2017,'Remy Hunter'),('523718504','7436984','Petrol','Audi','A4',2016,'Remy Hunter'),('523718504','74569321','Petrol','Audi','TT',2015,'Remy Hunter'),('305642472','7463298','Diesel','Audi','Q4',2018,'michael'),('485963247','8264532','Petrol','Seat','Leon',2018,'Hugo Frazier'),('718436985','8745632','Petrol','VW','Polo',2015,'Brett Mccabe'),('856326971','9536814','Diesel','BMW','1 Series',2017,'Sally Swan');
/*!40000 ALTER TABLE `car` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-27 17:40:29
