-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: myfueldb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quarterreports`
--

DROP TABLE IF EXISTS `quarterreports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quarterreports` (
  `QuarterNumber` enum('1','2','3','4') NOT NULL,
  `qr_Year` int NOT NULL,
  `reportType` enum('revenue_report','purchased_report','inventory_report') NOT NULL,
  `FK_gasStation_Id` varchar(50) NOT NULL,
  `theFile` longtext,
  PRIMARY KEY (`QuarterNumber`,`qr_Year`,`reportType`,`FK_gasStation_Id`),
  KEY `FK_gasStation_Id` (`FK_gasStation_Id`),
  CONSTRAINT `FK_gasStation_Id` FOREIGN KEY (`FK_gasStation_Id`) REFERENCES `gasstation` (`gasStationId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quarterreports`
--

LOCK TABLES `quarterreports` WRITE;
/*!40000 ALTER TABLE `quarterreports` DISABLE KEYS */;
INSERT INTO `quarterreports` VALUES ('2',2020,'revenue_report','2254','Revenue Report:\n\nGas Station Company:	Paz\nGas Station Name:	Paz_Karmiel\nGas Station Manager:	tal zilbermal\n\n\nIncome:	310.54$\n'),('2',2020,'revenue_report','2356','Revenue Report:\n\nGas Station Company:	Delek\nGas Station Name:	Delek_Nahariya\nGas Station Manager:	Alfonso Roman\n\n\nIncome:	2362.08$\n'),('2',2020,'revenue_report','3475','Revenue Report:\n\nGas Station Company:	Doralon\nGas Station Name:	Doralon Haifa\nGas Station Manager:	Freddie Hodgson\n\n\n'),('2',2020,'revenue_report','3477','Revenue Report:\n\nGas Station Company:	Doralon\nGas Station Name:	Doralon Netanya\nGas Station Manager:	Raul Patrick\n\n\nIncome:	209.18$\n'),('2',2020,'revenue_report','3478','Revenue Report:\n\nGas Station Company:	Ten\nGas Station Name:	Ten Tiberias\nGas Station Manager:	Angus Richardson\n\n\nIncome:	62041.72$\n'),('2',2020,'purchased_report','2254','Purchases Report:\n\nGas Station Company:	Paz\nGas Station Name:	Paz_Karmiel\nGas Station Manager:	tal zilbermal\n\n\nDiesel:\n	Number of Purcheses: 1\n	Total revenue: 310.54\n\n'),('2',2020,'purchased_report','2356','Purchases Report:\n\nGas Station Company:	Delek\nGas Station Name:	Delek_Nahariya\nGas Station Manager:	Alfonso Roman\n\n\nPetrol:\n	Number of Purcheses: 10\n	Total revenue: 2093.96\n\nDiesel:\n	Number of Purcheses: 1\n	Total revenue: 268.12\n\n'),('2',2020,'purchased_report','3475','Purchases Report:\n\nGas Station Company:	Doralon\nGas Station Name:	Doralon Haifa\nGas Station Manager:	Freddie Hodgson\n\n\n'),('2',2020,'purchased_report','3478','Purchases Report:\n\nGas Station Company:	Ten\nGas Station Name:	Ten Tiberias\nGas Station Manager:	Angus Richardson\n\n\nDiesel:\n	Number of Purcheses: 3\n	Total revenue: 41330.52\n\nPetrol:\n	Number of Purcheses: 6\n	Total revenue: 20711.20\n\n'),('2',2020,'inventory_report','2254','Inventory Report:\n\nGas Station Company:	Paz\nGas Station Name:	Paz_Karmiel\nGas Station Manager:	tal zilbermal\n\n\nPetrol:	10000/10000\nDiesel:	9940/10000\nScooterFuel:	10000/10000\n'),('2',2020,'inventory_report','2356','Inventory Report:\n\nGas Station Company:	Delek\nGas Station Name:	Delek_Nahariya\nGas Station Manager:	Alfonso Roman\n\n\nPetrol:	9547/10000\nDiesel:	9955/10000\nScooterFuel:	10000/10000\n'),('2',2020,'inventory_report','3475','Inventory Report:\n\nGas Station Company:	Doralon\nGas Station Name:	Doralon Haifa\nGas Station Manager:	Freddie Hodgson\n\n\nPetrol:	10000/10000\nDiesel:	10000/10000\nScooterFuel:	10000/10000\n'),('2',2020,'inventory_report','3478','Inventory Report:\n\nGas Station Company:	Ten\nGas Station Name:	Ten Tiberias\nGas Station Manager:	Angus Richardson\n\n\nPetrol:	5059/10000\nDiesel:	3958/10000\nScooterFuel:	10000/10000\n');
/*!40000 ALTER TABLE `quarterreports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-27 17:40:29
