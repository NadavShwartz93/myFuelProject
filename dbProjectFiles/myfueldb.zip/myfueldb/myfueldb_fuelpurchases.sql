-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: myfueldb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fuelpurchases`
--

DROP TABLE IF EXISTS `fuelpurchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fuelpurchases` (
  `FuelPurchasesId` int NOT NULL AUTO_INCREMENT,
  `FK_carLicenseNumber` varchar(50) DEFAULT NULL,
  `FK_gasStationId` varchar(50) DEFAULT NULL,
  `FK_fuelType` enum('Petrol','Diesel','ScooterFuel') DEFAULT NULL,
  `fuelAmount` varchar(50) DEFAULT NULL,
  `fuelPurchasePrice` varchar(50) DEFAULT NULL,
  `pumpNumber` varchar(50) DEFAULT NULL,
  `paymentType` enum('Cash','Credit_Card') DEFAULT NULL,
  `purchasesDay` date DEFAULT NULL,
  `purchasesTime` time DEFAULT NULL,
  PRIMARY KEY (`FuelPurchasesId`),
  KEY `FK_gasStationId` (`FK_gasStationId`),
  KEY `FK_fuelType` (`FK_fuelType`),
  KEY `FK_carLicenseNumber` (`FK_carLicenseNumber`),
  CONSTRAINT `fuelpurchases_ibfk_2` FOREIGN KEY (`FK_gasStationId`) REFERENCES `gasstation` (`gasStationId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fuelpurchases_ibfk_3` FOREIGN KEY (`FK_fuelType`) REFERENCES `fuel` (`fuelType`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fuelpurchases_ibfk_4` FOREIGN KEY (`FK_carLicenseNumber`) REFERENCES `car` (`carLicenseNumber`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuelpurchases`
--

LOCK TABLES `fuelpurchases` WRITE;
/*!40000 ALTER TABLE `fuelpurchases` DISABLE KEYS */;
INSERT INTO `fuelpurchases` VALUES (114,'12456397','2356','Petrol','40','278.02','2','Credit_Card','2020-06-13','22:00:55'),(115,'12456397','2356','Petrol','45','312.77','2','Credit_Card','2020-06-13','22:12:46'),(116,'12456397','2356','Petrol','32','222.41','2','Credit_Card','2020-06-13','22:13:01'),(117,'12456397','2356','Petrol','25','173.76','2','Credit_Card','2020-06-13','22:13:21'),(118,'4568712','2356','Petrol','41','196.48','2','Credit_Card','2020-06-13','22:32:49'),(119,'4568712','2356','Petrol','32','153.35','2','Credit_Card','2020-06-13','22:33:09'),(120,'8264532','2356','Petrol','45','215.65','2','Credit_Card','2020-06-13','22:33:41'),(121,'5412396','2356','Petrol','28','134.18','2','Credit_Card','2020-06-13','22:34:12'),(122,'6536974','2356','Petrol','35','167.73','2','Cash','2020-06-13','22:15:02'),(123,'74569321','2356','Petrol','50','239.61','2','Credit_Card','2020-06-13','22:15:02'),(125,'4156471','2256','Diesel','43','257.59','2','Credit_Card','2020-06-14','17:14:35'),(126,'5245637','2256','Diesel','45','269.57','2','Cash','2020-06-14','17:15:02'),(127,'9536814','3478','Diesel','42','226.44','2','Credit_Card','2020-06-14','21:10:55'),(128,'8264532','3478','Petrol','36','165.89','2','Cash','2020-06-15','17:21:13'),(129,'5412396','3478','Petrol','30','138.24','2','Cash','2020-06-15','17:22:05'),(130,'8264532','2255','Petrol','48','216.76','1','Credit_Card','2020-06-16','14:20:00'),(132,'8264532','3478','Petrol','25','115.20','1','Credit_Card','2020-06-17','10:15:53'),(133,'12456397','3476','Diesel','32','265.92','3','Cash','2020-06-17','10:17:29'),(135,'4568712','3478','Petrol','32','147.46','1','Credit_Card','2020-06-18','20:17:21'),(136,'5478936','2254','Diesel','60','310.54','1','Credit_Card','2020-06-19','18:20:38'),(137,'12456397','3478','Petrol','250','1200.00','1','Credit_Card','2020-06-20','08:47:16'),(138,'1789596','3478','Diesel','3000','24930.00','1','Credit_Card','2020-06-20','08:47:43'),(139,'4156471','3478','Diesel','3000','16174.08','1','Credit_Card','2020-06-20','08:48:00'),(140,'7436984','3478','Petrol','4568','18944.41','1','Credit_Card','2020-06-20','08:51:50'),(141,'7436984','3476','Petrol','126','522.55','1','Credit_Card','2020-06-20','08:56:47'),(142,'74569321','3476','Petrol','46','187.91','1','Credit_Card','2020-06-21','15:08:53'),(143,'8264532','2355','Petrol','46','204.61','1','Credit_Card','2020-06-21','15:09:17'),(144,'8745632','3475','Petrol','38','179.66','1','Credit_Card','2020-06-21','15:10:14'),(147,'5695174','2356','Diesel','55','296.52','1','Credit_Card','2020-06-21','15:16:00'),(148,'12456397','2254','Petrol','9933','47678.40','1','Credit_Card','2020-06-21','18:52:01'),(149,'12456397','2254','Diesel','8','66.48','1','Credit_Card','2020-06-21','18:54:14'),(150,'12456397','2254','Petrol','8','38.40','1','Credit_Card','2020-06-21','18:54:27'),(151,'12456397','2254','Petrol','9990','47952.00','1','Credit_Card','2020-06-22','11:31:05'),(152,'12456397','2254','Diesel','9920','82435.20','1','Credit_Card','2020-06-22','11:33:15'),(153,'12456397','2254','Petrol','5','24.00','1','Credit_Card','2020-06-22','11:34:36'),(154,'12456397','2254','Diesel','1','8.31','1','Credit_Card','2020-06-22','11:39:46'),(155,'12456397','2254','Petrol','9990','47952.00','1','Credit_Card','2020-06-22','11:41:03'),(156,'12456397','2254','Petrol','1000','4800.00','1','Credit_Card','2020-06-22','11:45:24'),(157,'12456397','2254','Petrol','8999','43195.20','1','Credit_Card','2020-06-22','11:45:51'),(158,'12456397','2254','Petrol','1000','4800.00','1','Credit_Card','2020-06-22','12:05:48');
/*!40000 ALTER TABLE `fuelpurchases` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-27 17:40:28
