-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: myfueldb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` varchar(50) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `creditCardNumber` varchar(50) DEFAULT NULL,
  `companyCustomer` tinyint(1) DEFAULT NULL,
  `creditCard_CVV` varchar(50) DEFAULT NULL,
  `creditCard_Month` enum('1','2','3','4','5','6','7','8','9','10','11','12') DEFAULT NULL,
  `creditCard_year` year DEFAULT NULL,
  `FK_modelType` enum('NormalFueling','RegularMonthlySubscriptionOneCar','RegularMonthlySubscriptionSomeCars','FullMonthlySubscriptionOneCar') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_modelType` (`FK_modelType`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`FK_modelType`) REFERENCES `model` (`modelType`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('132584962','Manuel','Mosley','manuelmosley@gmail.com','1589632546132587',1,'123','3',2023,'RegularMonthlySubscriptionSomeCars'),('305642472','Michael','Eliasof','michaeleliasog@gmail.com','1235698563254174',0,'124','6',2023,'RegularMonthlySubscriptionSomeCars'),('485963247','Hugo','Frazier','hugofrazier@gmail.com','1478521478963258',0,'874','3',2022,'FullMonthlySubscriptionOneCar'),('523718504','Remy','Hunter','remyhunter@gmail.com','2465791340529038',1,'936','10',2025,'RegularMonthlySubscriptionSomeCars'),('718436985','Brett','Mccabe','brettmccabe@gmail.com','1785345817452587',0,'197','4',2026,'NormalFueling'),('856326971','Sally','Swan','sallyswan@gmail.com','1369865478941256',1,'321','8',2026,'RegularMonthlySubscriptionSomeCars');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-27 17:40:29
